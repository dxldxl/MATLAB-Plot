% demo romeo_juliet
clc;clear
% 基本数据
strData=readcell('romeo_juliet.txt');
strData=strData(:,1);
nameStr={'Romeo','Juliet','Friar Laurence','Friar John','Abraham','Balthasar',...
         'Montague','Lady Montague','Benvolio','Apothecary','Mercutio','Prince','Paris','Tybalt',...
         'Sampson','Gregory','Lady Capulet','Capulet','Nurse','Peter'};
% 各个人物家族分类
classNum=[1,2,4,4,1,1,1,1,1,4,3,3,3,2,2,2,2,2,2,2];
classStr={'House Montague','House Capulet','House Escalus','Other personages'};
% 各个人物点位置
posXY=[-0.1598   -0.0682; 0.3117   -0.0060;-0.0389    0.4154;-0.1874    0.5155;
       -0.3877    0.5691;-0.6693    0.5397;-0.8092    0.2599;-0.7522   -0.0959;
       -0.5915   -0.3515;-0.4465   -0.5294;-0.2668   -0.6503;-0.0060   -0.7867;
        0.2202   -0.6503; 0.4275   -0.5173; 0.5933   -0.3515; 0.7228   -0.1563;
        0.8040    0.1045; 0.7642    0.3653; 0.5259    0.5622; 0.2323    0.5121];
colorList=[48,115,100;177,58,71;252,193,13;108,60,143]./255;

% =========================================================================
% 统计各个人物前后出现次数
orderList=zeros(size(strData));
for i=1:length(nameStr)
    orderList(strcmpi(nameStr{i},strData))=i;
end
orderList(orderList==0)=[];
corrMat=zeros(length(nameStr));
for i=1:length(orderList)-1
    corrMat(orderList(i),orderList(i+1))=corrMat(orderList(i),orderList(i+1))+1;
end
corrMat=corrMat+corrMat.';
% =========================================================================
% 开始绘图

% 坐标区域修饰
figure('Position',[400,100,850,850],'Name','slandarer')
ax=gca;hold on
ax.XLim=[-1,1];
ax.YLim=[-1,1];
ax.Color=[0,0,0];
ax.XTick=[];
ax.YTick=[];
ax.DataAspectRatio=[1,1,1];
maxWidth=max(corrMat(corrMat>0));
minWidth=min(corrMat(corrMat>0));
ttList=linspace(0,1,3)';
% 循环绘图
for i=1:size(corrMat,1)  
    for j=i+1:size(corrMat,2)
        if corrMat(i,j)>0
            tW=(corrMat(i,j)-minWidth)./(maxWidth-minWidth);
            colorData=(1-ttList).*colorList(classNum(i),:)+ttList.*colorList(classNum(j),:);
            CData(:,:,1)=colorData(:,1);
            CData(:,:,2)=colorData(:,2);
            CData(:,:,3)=colorData(:,3);
            % 绘制连线
            fill(linspace(posXY(i,1),posXY(j,1),3),...
                 linspace(posXY(i,2),posXY(j,2),3),[0,0,0],'LineWidth',tW.*6+2.5,...
                 'CData',CData,'EdgeColor','interp','EdgeAlpha',.5,'FaceAlpha',.5)
        end
    end
    % 绘制人物圆点
    scatter(posXY(i,1),posXY(i,2),30,'filled','LineWidth',1.2,...
        'MarkerFaceColor',colorList(classNum(i),:),'MarkerEdgeColor',[.7,.7,.7]); 
end
% 绘制人物文字
for i=1:size(corrMat,1)  
    text(posXY(i,1),posXY(i,2)-.001,nameStr{i},'FontName','Cambria','FontSize',13,...
        'HorizontalAlignment','center','Color',[1,1,1]);
end
% 绘制标题
text(0,0.8,'ROMEO & JULIET','FontSize',30,'FontWeight','bold','Color',...
    [1,1,1],'HorizontalAlignment','center','FontName','Cambria')
text(0,0.68,'Number of conversations between characters','FontWeight','bold','Color',...
    [1,1,1].*.7,'HorizontalAlignment','center','FontName','Cambria','FontSize',15)

% 绘制图例
lgdSet(length(classStr))=nan;
for i=1:length(classStr)
    lgdSet(i)=fill([0,0],[0,0],colorList(i,:));
end
lgdHdl=legend(lgdSet,classStr,'Box','off','Location','South','Orientation','horizontal',...
    'TextColor',[1,1,1],'FontName','Cambria','FontSize',12);
lgdHdl.ItemTokenSize=[8,8];
